"""
Example: Login flow tests — used as RAG training context.
"""
import pytest
from playwright.async_api import Page, expect


class LoginPage:
    def __init__(self, page: Page, base_url: str):
        self.page = page
        self.base_url = base_url
        self.email    = page.get_by_label("Email")
        self.password = page.get_by_label("Password")
        self.submit   = page.get_by_role("button", name="Sign in")
        self.error    = page.get_by_role("alert")

    async def goto(self):
        await self.page.goto(f"{self.base_url}/login")

    async def login(self, email: str, password: str):
        await self.email.fill(email)
        await self.password.fill(password)
        await self.submit.click()


@pytest.mark.asyncio
async def test_successful_login(page: Page):
    """Valid credentials redirect to dashboard."""
    lp = LoginPage(page, "http://localhost:3000")
    await lp.goto()
    await lp.login("user@example.com", "correct-password")
    await expect(page).to_have_url("http://localhost:3000/dashboard")
    await expect(page.get_by_role("heading", name="Dashboard")).to_be_visible()


@pytest.mark.asyncio
async def test_invalid_password(page: Page):
    """Wrong password shows error message."""
    lp = LoginPage(page, "http://localhost:3000")
    await lp.goto()
    await lp.login("user@example.com", "wrong-password")
    await expect(lp.error).to_contain_text("Invalid credentials")
    await expect(page).to_have_url("http://localhost:3000/login")


@pytest.mark.asyncio
async def test_empty_email_shows_validation(page: Page):
    """Empty email field shows HTML5 validation."""
    lp = LoginPage(page, "http://localhost:3000")
    await lp.goto()
    await lp.submit.click()
    # Email field should be invalid / focused
    await expect(lp.email).to_be_focused()


@pytest.mark.asyncio
async def test_logout_clears_session(page: Page):
    """Logging out redirects back to login page."""
    lp = LoginPage(page, "http://localhost:3000")
    await lp.goto()
    await lp.login("user@example.com", "correct-password")
    await expect(page).to_have_url("http://localhost:3000/dashboard")

    await page.get_by_role("button", name="Log out").click()
    await expect(page).to_have_url("http://localhost:3000/login")
