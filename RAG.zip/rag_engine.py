"""
RAG Engine for Playwright Test Generation
Handles: ingestion → embedding → retrieval → generation → execution
"""

import os
import re
import ast
import json
import subprocess
from pathlib import Path
from typing import Optional
from datetime import datetime

import chromadb
from chromadb.utils import embedding_functions
from anthropic import Anthropic

# ─── CONFIG ────────────────────────────────────────────────────────────────
CHROMA_DIR   = Path(__file__).parent.parent / "chroma_db"
DOCS_DIR     = Path(__file__).parent.parent / "docs"
TESTS_DIR    = Path(__file__).parent.parent / "tests" / "generated"
RESULTS_DIR  = Path(__file__).parent.parent / "results"
COLLECTION   = "playwright_rag"
CHUNK_SIZE   = 800
CHUNK_OVERLAP = 100
TOP_K        = 6

SYSTEM_PROMPT = """\
You are an expert Playwright test engineer who writes Python tests.

STRICT RULES:
1. Use async/await with pytest-playwright fixtures (page, async_playwright)
2. Prefer semantic locators: get_by_role(), get_by_label(), get_by_text(), get_by_placeholder()
3. Use expect(locator).to_be_visible() / to_have_value() / to_contain_text() for assertions
4. Follow Page Object Model (POM) — define a class for the page
5. Use @pytest.mark.asyncio decorator on every test
6. Add descriptive docstrings and inline comments
7. Handle waits with expect(...).to_be_visible(timeout=5000) — never time.sleep()
8. Return ONLY a single Python code block — no explanation, no markdown outside the block

OUTPUT FORMAT:
```python
# your complete test code here
```
"""

# ─── CHUNKER ───────────────────────────────────────────────────────────────
def chunk_text(text: str, source: str) -> list[dict]:
    """Split text into overlapping chunks respecting Python/Markdown structure."""
    separators = ["\n\ndef ", "\n\nclass ", "\n## ", "\n\n", "\n", " "]
    chunks = []
    
    # Try to split on logical boundaries first
    current = []
    current_len = 0
    
    lines = text.split("\n")
    for line in lines:
        current.append(line)
        current_len += len(line) + 1
        
        if current_len >= CHUNK_SIZE:
            chunk_text_str = "\n".join(current)
            chunks.append({"text": chunk_text_str, "source": source})
            # Keep overlap
            overlap_lines = []
            overlap_len = 0
            for l in reversed(current):
                if overlap_len + len(l) > CHUNK_OVERLAP:
                    break
                overlap_lines.insert(0, l)
                overlap_len += len(l) + 1
            current = overlap_lines
            current_len = overlap_len
    
    if current:
        chunks.append({"text": "\n".join(current), "source": source})
    
    return chunks


# ─── INGESTOR ──────────────────────────────────────────────────────────────
class DocumentIngestor:
    def __init__(self, collection):
        self.collection = collection

    def ingest_directory(self, directory: Path, extensions: list[str] = None) -> int:
        if extensions is None:
            extensions = [".py", ".md", ".txt", ".html", ".feature"]
        
        all_chunks = []
        files = []
        
        for ext in extensions:
            files.extend(directory.rglob(f"*{ext}"))
        
        for filepath in files:
            try:
                text = filepath.read_text(encoding="utf-8", errors="ignore")
                if not text.strip():
                    continue
                chunks = chunk_text(text, str(filepath.name))
                all_chunks.extend(chunks)
                print(f"  ✓ {filepath.name} → {len(chunks)} chunks")
            except Exception as e:
                print(f"  ✗ {filepath.name}: {e}")
        
        if all_chunks:
            self._upsert_chunks(all_chunks)
        
        return len(all_chunks)

    def ingest_text(self, text: str, source: str = "manual") -> int:
        chunks = chunk_text(text, source)
        self._upsert_chunks(chunks)
        return len(chunks)

    def _upsert_chunks(self, chunks: list[dict]):
        texts  = [c["text"] for c in chunks]
        metas  = [{"source": c["source"]} for c in chunks]
        ids    = [f"{c['source'][:40]}_{i}_{hash(c['text']) & 0xFFFFFF}"
                  for i, c in enumerate(chunks)]
        self.collection.upsert(documents=texts, metadatas=metas, ids=ids)


# ─── RETRIEVER ─────────────────────────────────────────────────────────────
class Retriever:
    def __init__(self, collection):
        self.collection = collection

    def retrieve(self, query: str, k: int = TOP_K) -> list[str]:
        results = self.collection.query(
            query_texts=[query],
            n_results=min(k, self.collection.count() or 1),
            include=["documents", "metadatas", "distances"]
        )
        
        docs      = results["documents"][0]
        metas     = results["metadatas"][0]
        distances = results["distances"][0]
        
        # Simple MMR-style deduplication: drop chunks with >85% similarity to already chosen
        chosen = []
        chosen_texts = []
        for doc, meta, dist in zip(docs, metas, distances):
            if not chosen_texts or not any(
                _similarity(doc, c) > 0.85 for c in chosen_texts
            ):
                chosen.append(f"[Source: {meta['source']}]\n{doc}")
                chosen_texts.append(doc)
        
        return chosen


def _similarity(a: str, b: str) -> float:
    """Quick Jaccard similarity on word sets."""
    sa = set(a.lower().split())
    sb = set(b.lower().split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


# ─── GENERATOR ─────────────────────────────────────────────────────────────
class TestGenerator:
    def __init__(self, retriever: Retriever):
        self.retriever = retriever
        self.client    = Anthropic()

    def generate(self, query: str, base_url: str = "http://localhost:3000") -> str:
        chunks = self.retriever.retrieve(query)
        context = "\n\n---\n\n".join(chunks) if chunks else "(no context retrieved)"
        
        user_message = f"""\
Context from knowledge base:
{context}

---
Test request: {query}
Base URL for tests: {base_url}

Generate a complete pytest-playwright test file."""

        response = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2048,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_message}]
        )
        
        return response.content[0].text

    def generate_with_retry(self, query: str, base_url: str = "http://localhost:3000",
                            max_retries: int = 2) -> str:
        """Generate test; on syntax error, feed error back and retry."""
        raw = self.generate(query, base_url)
        
        for attempt in range(max_retries):
            code = extract_code(raw)
            try:
                ast.parse(code)
                return raw  # valid Python
            except SyntaxError as e:
                print(f"  ⚠ Syntax error on attempt {attempt+1}: {e}")
                # Feed the error back to Claude for self-correction
                fix_prompt = f"""\
This code has a SyntaxError: {e}

```python
{code}
```

Fix the syntax error and return the corrected complete file."""
                raw = self.client.messages.create(
                    model="claude-sonnet-4-20250514",
                    max_tokens=2048,
                    system=SYSTEM_PROMPT,
                    messages=[{"role": "user", "content": fix_prompt}]
                ).content[0].text
        
        return raw  # return last attempt regardless


# ─── EXECUTOR ──────────────────────────────────────────────────────────────
class TestExecutor:
    def __init__(self, ingestor: DocumentIngestor):
        self.ingestor = ingestor

    def run(self, test_path: Path, headed: bool = False) -> dict:
        cmd = [
            "python", "-m", "pytest", str(test_path),
            "--tb=short", "-q",
            f"--junitxml={RESULTS_DIR / test_path.stem}_result.xml",
            "--asyncio-mode=auto",
        ]
        if headed:
            cmd.append("--headed")
        
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=test_path.parent.parent)
        
        passed = result.returncode == 0
        output = {
            "passed":    passed,
            "returncode": result.returncode,
            "stdout":    result.stdout,
            "stderr":    result.stderr,
            "test_file": str(test_path),
            "timestamp": datetime.now().isoformat(),
        }
        
        # Save run log
        log_path = RESULTS_DIR / f"{test_path.stem}_log.json"
        log_path.write_text(json.dumps(output, indent=2))
        
        # ── Feedback loop ────────────────────────────────────────────
        if not passed:
            error_doc = (
                f"# Runtime error from test: {test_path.name}\n"
                f"# Timestamp: {output['timestamp']}\n\n"
                f"{result.stderr}\n{result.stdout}"
            )
            n = self.ingestor.ingest_text(error_doc, source=f"error_{test_path.stem}")
            print(f"  ↺ Feedback loop: ingested {n} error chunk(s) back into vector store")
        
        return output


# ─── CODE EXTRACTOR ────────────────────────────────────────────────────────
def extract_code(llm_output: str) -> str:
    match = re.search(r"```python\n(.*?)```", llm_output, re.DOTALL)
    if match:
        return match.group(1).strip()
    # Fallback: strip any markdown fences
    return re.sub(r"^```.*?\n|```$", "", llm_output, flags=re.MULTILINE).strip()


# ─── PIPELINE ORCHESTRATOR ─────────────────────────────────────────────────
class PlaywrightRAG:
    """
    Top-level orchestrator.
    Usage:
        rag = PlaywrightRAG()
        rag.ingest()                          # ingest docs/
        code = rag.generate("login test")     # generate test
        result = rag.execute(code, "login")   # run it
    """

    def __init__(self):
        # Ensure dirs exist
        for d in [CHROMA_DIR, DOCS_DIR, TESTS_DIR, RESULTS_DIR]:
            d.mkdir(parents=True, exist_ok=True)

        # Chroma with built-in sentence-transformer embeddings (no API key needed)
        ef = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="all-MiniLM-L6-v2"
        )
        client     = chromadb.PersistentClient(path=str(CHROMA_DIR))
        collection = client.get_or_create_collection(
            name=COLLECTION,
            embedding_function=ef,
            metadata={"hnsw:space": "cosine"}
        )

        self.ingestor  = DocumentIngestor(collection)
        self.retriever = Retriever(collection)
        self.generator = TestGenerator(self.retriever)
        self.executor  = TestExecutor(self.ingestor)

    # ── Public API ──────────────────────────────────────────────────────────

    def ingest(self, directory: Path = None) -> int:
        """Ingest all docs from a directory (default: docs/)."""
        directory = directory or DOCS_DIR
        print(f"\n📥 Ingesting documents from {directory}...")
        n = self.ingestor.ingest_directory(directory)
        print(f"   Total chunks stored: {n}")
        return n

    def ingest_text(self, text: str, source: str = "manual") -> int:
        return self.ingestor.ingest_text(text, source)

    def generate(self, query: str, base_url: str = "http://localhost:3000") -> str:
        """Generate a Playwright test for the given query."""
        print(f"\n🤖 Generating test: {query!r}")
        raw = self.generator.generate_with_retry(query, base_url)
        return extract_code(raw)

    def execute(self, code: str, test_name: str,
                headed: bool = False) -> dict:
        """Write and run a test. Returns result dict."""
        safe_name = re.sub(r"[^\w]", "_", test_name.lower())
        test_path = TESTS_DIR / f"test_{safe_name}.py"
        test_path.write_text(code)
        print(f"\n🎭 Running: {test_path.name}")
        result = self.executor.run(test_path, headed=headed)
        status = "✅ PASSED" if result["passed"] else "❌ FAILED"
        print(f"   {status}")
        if not result["passed"]:
            print(f"   stderr: {result['stderr'][:300]}")
        return result

    def run(self, query: str, test_name: str,
            base_url: str = "http://localhost:3000",
            headed: bool = False) -> dict:
        """Full pipeline: generate → write → execute."""
        code   = self.generate(query, base_url)
        result = self.execute(code, test_name, headed=headed)
        result["generated_code"] = code
        return result
