#!/usr/bin/env python3
"""
Playwright RAG CLI
Usage examples:
    python main.py ingest
    python main.py generate "login test for /auth page"
    python main.py run "checkout flow with credit card" --name checkout --url http://localhost:3000
    python main.py chat
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))
from rag_engine import PlaywrightRAG, DOCS_DIR, TESTS_DIR


def cmd_ingest(args, rag: PlaywrightRAG):
    directory = Path(args.dir) if args.dir else DOCS_DIR
    n = rag.ingest(directory)
    print(f"✅ Done. {n} chunks stored.")


def cmd_generate(args, rag: PlaywrightRAG):
    code = rag.generate(args.query, args.url)
    print("\n--- Generated Test ---")
    print(code)
    if args.output:
        out = Path(args.output)
        out.write_text(code)
        print(f"\n💾 Saved to {out}")


def cmd_run(args, rag: PlaywrightRAG):
    result = rag.run(
        query=args.query,
        test_name=args.name or args.query[:30],
        base_url=args.url,
        headed=args.headed,
    )
    print(f"\n📄 Code saved to: {TESTS_DIR}/test_*.py")
    if args.verbose:
        print("\n--- stdout ---")
        print(result["stdout"])


def cmd_chat(args, rag: PlaywrightRAG):
    """Interactive REPL for test generation."""
    print("\n🎭 Playwright RAG — interactive mode")
    print("Commands: ingest <path>, generate <query>, run <query>, exit\n")
    while True:
        try:
            line = input("rag> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if not line:
            continue
        if line in ("exit", "quit", "q"):
            break

        parts = line.split(" ", 1)
        cmd   = parts[0]
        rest  = parts[1] if len(parts) > 1 else ""

        if cmd == "ingest":
            rag.ingest(Path(rest) if rest else DOCS_DIR)
        elif cmd == "generate":
            code = rag.generate(rest or "write a basic smoke test")
            print(code)
        elif cmd == "run":
            rag.run(rest, test_name=rest[:30])
        elif cmd == "add":
            # add inline text to vector store
            rag.ingest_text(rest, source="cli_manual")
            print("  ✓ Added to vector store")
        else:
            print("  Unknown command. Try: ingest / generate / run / add / exit")


def main():
    parser = argparse.ArgumentParser(description="Playwright RAG Test Generator")
    sub = parser.add_subparsers(dest="command")

    # ingest
    p_ingest = sub.add_parser("ingest", help="Ingest documents into vector store")
    p_ingest.add_argument("--dir", help="Directory to ingest (default: docs/)")

    # generate
    p_gen = sub.add_parser("generate", help="Generate a Playwright test (no execution)")
    p_gen.add_argument("query", help="Natural language test description")
    p_gen.add_argument("--url", default="http://localhost:3000", help="Base URL")
    p_gen.add_argument("--output", help="Save generated code to file")

    # run
    p_run = sub.add_parser("run", help="Generate and execute a test")
    p_run.add_argument("query", help="Natural language test description")
    p_run.add_argument("--name", help="Test name (used for filename)")
    p_run.add_argument("--url", default="http://localhost:3000", help="Base URL")
    p_run.add_argument("--headed", action="store_true", help="Run browser in headed mode")
    p_run.add_argument("--verbose", action="store_true", help="Print full output")

    # chat
    sub.add_parser("chat", help="Interactive REPL mode")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    rag = PlaywrightRAG()

    if args.command == "ingest":
        cmd_ingest(args, rag)
    elif args.command == "generate":
        cmd_generate(args, rag)
    elif args.command == "run":
        cmd_run(args, rag)
    elif args.command == "chat":
        cmd_chat(args, rag)


if __name__ == "__main__":
    main()
