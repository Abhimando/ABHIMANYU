# Playwright RAG — Automated Test Generator

Generate, run, and self-improve Playwright tests using RAG + Claude.

## Setup

```bash
# 1. Install Python deps
pip install -r requirements.txt

# 2. Install Playwright browsers
playwright install chromium

# 3. Set your Anthropic API key
export ANTHROPIC_API_KEY=sk-ant-...
```

## Project layout

```
playwright_rag/
├── main.py                  # CLI entry point
├── src/
│   └── rag_engine.py        # Core RAG pipeline
├── docs/                    # <-- put YOUR docs here
│   ├── playwright_best_practices.md
│   └── example_login_tests.py
├── tests/
│   └── generated/           # LLM-generated tests land here
├── results/                 # JUnit XML + JSON run logs
├── chroma_db/               # Persisted vector store
├── conftest.py
└── requirements.txt
```

## Usage

### 1. Ingest your documentation
```bash
# Ingest everything in docs/ (default)
python main.py ingest

# Ingest a custom directory
python main.py ingest --dir ./my_specs
```

Supported file types: `.py`, `.md`, `.txt`, `.html`, `.feature`

### 2. Generate a test (without running)
```bash
python main.py generate "login test for /auth page with remember me checkbox"
python main.py generate "form validation on registration page" --output tests/test_register.py
```

### 3. Generate + execute in one shot
```bash
python main.py run "checkout flow with visa card" --name checkout --url http://localhost:3000
python main.py run "search products by category" --headed   # open browser window
```

### 4. Interactive REPL
```bash
python main.py chat
```
```
rag> ingest ./docs
rag> generate login test with OAuth
rag> run forgot password flow
rag> add The /reset endpoint accepts POST with email field
rag> exit
```

## Python API

```python
from src.rag_engine import PlaywrightRAG

rag = PlaywrightRAG()

# Ingest docs
rag.ingest()                                          # docs/ folder
rag.ingest_text("The /cart page has an 'Add' button", source="manual")

# Generate only
code = rag.generate("add item to cart and verify total")
print(code)

# Full pipeline
result = rag.run(
    query="login with valid credentials",
    test_name="login_valid",
    base_url="http://localhost:3000",
)
print("Passed:", result["passed"])
print("Code:\n", result["generated_code"])
```

## How it works

```
docs/ + .py files
       │
       ▼
  Text chunker (800 char chunks, 100 overlap)
       │
       ▼
  Embeddings (sentence-transformers/all-MiniLM-L6-v2, runs locally)
       │
       ▼
  ChromaDB (persisted vector store)
       │
  User query
       │
       ▼
  Top-6 relevant chunks (MMR dedup)
       │
       ▼
  Claude (system prompt + context + query)  →  raw Python code
       │
       ▼
  AST syntax check → auto-retry on SyntaxError
       │
       ▼
  Write to tests/generated/test_*.py
       │
       ▼
  pytest-playwright execution
       │
       ├── PASS → done
       └── FAIL → error re-ingested into vector store (feedback loop)
```

## Tips

- **Add your app's HTML/selectors** to `docs/` for better locator accuracy.
- **Add BDD `.feature` files** — RAG uses them as test scenarios.
- **Run `ingest` after adding new docs** — the vector store persists between runs.
- The feedback loop means failed tests **teach the system** to avoid the same mistakes.
