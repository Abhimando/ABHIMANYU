# Playwright Python Best Practices

## Locator Strategy (preferred order)

Use semantic locators in this priority:
1. `page.get_by_role("button", name="Submit")` — ARIA roles
2. `page.get_by_label("Email")` — form labels
3. `page.get_by_placeholder("Enter email")` — placeholder text
4. `page.get_by_text("Sign in")` — visible text
5. `page.get_by_test_id("login-btn")` — data-testid attributes
6. `page.locator("css=selector")` — CSS (last resort)

Never use XPath. Avoid index-based locators like `nth(0)`.

## Assertions (always use expect, never assert)

```python
from playwright.async_api import expect

await expect(page.get_by_role("heading")).to_be_visible()
await expect(page.get_by_label("Email")).to_have_value("user@example.com")
await expect(page).to_have_url("https://example.com/dashboard")
await expect(page.get_by_text("Welcome")).to_contain_text("Welcome")
await expect(page.locator(".error")).to_have_count(0)
```

## Fixtures and conftest.py

```python
# conftest.py
import pytest
from playwright.async_api import async_playwright

@pytest.fixture(scope="session")
def base_url():
    return "http://localhost:3000"

@pytest.fixture
async def authenticated_page(page, base_url):
    await page.goto(f"{base_url}/login")
    await page.get_by_label("Email").fill("test@example.com")
    await page.get_by_label("Password").fill("password123")
    await page.get_by_role("button", name="Sign in").click()
    await expect(page).to_have_url(f"{base_url}/dashboard")
    return page
```

## Page Object Model (POM)

```python
# pages/login_page.py
from playwright.async_api import Page, expect

class LoginPage:
    def __init__(self, page: Page, base_url: str):
        self.page = page
        self.base_url = base_url
        self.email_input = page.get_by_label("Email")
        self.password_input = page.get_by_label("Password")
        self.submit_btn = page.get_by_role("button", name="Sign in")
        self.error_msg = page.get_by_role("alert")

    async def goto(self):
        await self.page.goto(f"{self.base_url}/login")

    async def login(self, email: str, password: str):
        await self.email_input.fill(email)
        await self.password_input.fill(password)
        await self.submit_btn.click()

    async def expect_error(self, message: str):
        await expect(self.error_msg).to_contain_text(message)
```

## Waits — NEVER use time.sleep()

```python
# Wait for element
await expect(page.get_by_role("spinner")).to_be_hidden(timeout=10000)

# Wait for navigation
async with page.expect_navigation():
    await page.get_by_role("button", name="Submit").click()

# Wait for network request
async with page.expect_response("**/api/login") as resp:
    await page.get_by_role("button", name="Sign in").click()
response = await resp.value
assert response.ok
```

## Test structure template

```python
import pytest
from playwright.async_api import Page, expect

@pytest.mark.asyncio
async def test_feature_name(page: Page):
    """Describe what this test verifies."""
    # Arrange
    await page.goto("http://localhost:3000/page")
    
    # Act
    await page.get_by_role("button", name="Action").click()
    
    # Assert
    await expect(page.get_by_text("Success")).to_be_visible()
```
