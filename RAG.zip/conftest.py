"""
Shared pytest fixtures for generated tests.
Place this file in the project root or tests/ directory.
"""
import pytest
from playwright.async_api import async_playwright


@pytest.fixture(scope="session")
def base_url():
    return "http://localhost:3000"


@pytest.fixture(scope="session")
def browser_type_launch_args():
    """Pass extra browser args — e.g. disable sandbox in CI."""
    return {"args": ["--no-sandbox", "--disable-dev-shm-usage"]}
